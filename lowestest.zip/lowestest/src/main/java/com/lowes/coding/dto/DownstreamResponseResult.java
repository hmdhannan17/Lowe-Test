package com.lowes.coding.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@JsonTypeName(value = "results")
public class DownstreamResponseResult {

	private String category;
	private String type;
	private String difficulty;
	private String question;
	
	@JsonProperty(value =  "correct_answer")
	private String correctAnswer;
	
	@JsonProperty(value =  "incorrect_answers")
	private List<String> incorrectAnswers;

}
