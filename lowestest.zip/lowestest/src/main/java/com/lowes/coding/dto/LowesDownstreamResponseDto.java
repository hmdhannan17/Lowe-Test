package com.lowes.coding.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class LowesDownstreamResponseDto {
	
	@JsonProperty(value =  "response_code")
	private Integer responseCode;
	
	@JsonProperty(value =  "results")
	private List<DownstreamResponseResult> results;

}
