package com.lowes.coding.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonTypeName(value = "quiz")
public class LowesTestQuizDto {
	
	private String category;
	private List<LowesTestResults> results;
	
}
