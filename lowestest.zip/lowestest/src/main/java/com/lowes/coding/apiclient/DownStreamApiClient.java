package com.lowes.coding.apiclient;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lowes.coding.dto.LowesDownstreamResponseDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DownStreamApiClient {
	
	/**
	 * method to call downstream services and return response dto
	 */
	public LowesDownstreamResponseDto getFromDownStreamService(String url) {
		RestTemplate restTemplate = new RestTemplate();
		LowesDownstreamResponseDto responseResults1 = new LowesDownstreamResponseDto();
		try {
			responseResults1 = restTemplate.getForEntity(url, LowesDownstreamResponseDto.class).getBody();
		} catch (Exception e) {
			log.error(e.toString());
		}
		return responseResults1;
	}

}
