package com.lowes.coding.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonTypeName(value = "results")
public class LowesTestResults {

	private String type;
	
	private String difficulty;
	
	private String question;
	
	@JsonProperty(value = "all_answers")
	private List<String> allAnswers;
	
	@JsonProperty(value = "correct_answer")
	private String correctAnswer;

}
