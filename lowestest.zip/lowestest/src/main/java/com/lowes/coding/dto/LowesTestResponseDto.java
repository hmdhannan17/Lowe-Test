package com.lowes.coding.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LowesTestResponseDto {
	
	private List<LowesTestQuizDto> quiz;

}
