package com.lowes.coding.service;

import org.springframework.stereotype.Service;

import com.lowes.coding.dto.LowesTestResponseDto;


@Service
public interface ExerciseService {
	
	LowesTestResponseDto getCodingExerciseFromDownstream();
}
