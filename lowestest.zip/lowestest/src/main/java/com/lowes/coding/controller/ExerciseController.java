package com.lowes.coding.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.lowes.coding.dto.LowesTestResponseDto;
import com.lowes.coding.service.ExerciseService;


@RestController
@RequestMapping("/exercise")
public class ExerciseController {
	
	@Autowired
	ExerciseService lowesApplicationService;
	
	/**
	 * @return LowesTestResponseDto
	 */
	@GetMapping("quiz")
	public ResponseEntity<LowesTestResponseDto> getCodingExerciseQuiz(){
		return ResponseEntity.ok(lowesApplicationService.getCodingExerciseFromDownstream());
				
	}

}
